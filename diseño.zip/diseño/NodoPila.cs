﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clases
{
    public class NodoPila
    {
        public string accion;
        public NodoPila siguiente;
    }
}
